function popup(name,email) {
    let a = document.getElementById("name").value;
    let b = document.getElementById("email").value;
    window.alert("You have successfully signed up for our newsletter! \n" + "Name: " + a + "\n" + "E-mail: " + b);
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
}